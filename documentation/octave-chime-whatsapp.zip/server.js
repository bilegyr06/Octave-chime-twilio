/**
 * Octave Chime — WhatsApp transaction alerts backend
 * Serves the demo front-end AND sends real messages via the WhatsApp Cloud API.
 * The access token stays here on the server — never in the browser.
 *
 * Node 18+ (uses built-in fetch). Run: npm install && npm start
 */
"use strict";
const express = require("express");
const path = require("path");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const {
  WHATSAPP_TOKEN,
  WHATSAPP_PHONE_NUMBER_ID,
  RECIPIENT_MSISDN = "2348032002338",
  GRAPH_VERSION = "v22.0",
  TEMPLATE_NAME = "hello_world",     // set to your approved UTILITY template for real alerts
  TEMPLATE_LANG = "en_US",
  SUMMARY_TEMPLATE_NAME = "",         // optional separate template for the EOD summary
  PORT = 3000,
} = process.env;

const configured = () => Boolean(WHATSAPP_TOKEN && WHATSAPP_PHONE_NUMBER_ID);
const graphUrl = () => `https://graph.facebook.com/${GRAPH_VERSION}/${WHATSAPP_PHONE_NUMBER_ID}/messages`;
const naira = n => "₦" + Number(n || 0).toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const p = t => ({ type: "text", text: String(t == null ? "-" : t) });

// core sender — one place that calls Meta
async function sendToWhatsApp(payload) {
  const res = await fetch(graphUrl(), {
    method: "POST",
    headers: { Authorization: `Bearer ${WHATSAPP_TOKEN}`, "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const e = new Error(data?.error?.message || `Graph API responded ${res.status}`);
    e.details = data;
    throw e;
  }
  return data;
}

const helloWorld = to => ({
  messaging_product: "whatsapp", to, type: "template",
  template: { name: "hello_world", language: { code: "en_US" } },
});

// health — the front-end pings this before going live
app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: configured(), recipient: RECIPIENT_MSISDN, template: TEMPLATE_NAME, graph: GRAPH_VERSION });
});

// prove connectivity with the pre-approved hello_world template
app.post("/api/send-test", async (req, res) => {
  if (!configured()) return res.status(400).json({ ok: false, error: "Server not configured — set WHATSAPP_TOKEN and WHATSAPP_PHONE_NUMBER_ID in .env" });
  const to = req.body?.to || RECIPIENT_MSISDN;
  try {
    const data = await sendToWhatsApp(helloWorld(to));
    res.json({ ok: true, id: data?.messages?.[0]?.id, data });
  } catch (e) { res.status(502).json({ ok: false, error: e.message, details: e.details }); }
});

// real transaction alert
app.post("/api/send-alert", async (req, res) => {
  if (!configured()) return res.status(400).json({ ok: false, error: "Server not configured." });
  const b = req.body || {};
  const to = b.to || RECIPIENT_MSISDN;
  try {
    let payload;
    if (TEMPLATE_NAME && TEMPLATE_NAME !== "hello_world") {
      // Your approved UTILITY template. Expected body variables (edit to match your template):
      //   {{1}} kind  {{2}} amount  {{3}} channel  {{4}} party  {{5}} balance  {{6}} ref
      const kind = b.kind === "credit" ? "Credit" : "Debit";
      const params = [kind, naira(b.amount), b.channel || "Transaction", b.party || "-", naira(b.balance), b.ref || "-"].map(p);
      payload = {
        messaging_product: "whatsapp", to, type: "template",
        template: { name: TEMPLATE_NAME, language: { code: TEMPLATE_LANG }, components: [{ type: "body", parameters: params }] },
      };
    } else {
      // No custom template configured yet — hello_world still proves end-to-end delivery.
      payload = helloWorld(to);
    }
    const data = await sendToWhatsApp(payload);
    res.json({ ok: true, id: data?.messages?.[0]?.id, usedTemplate: (TEMPLATE_NAME !== "hello_world" ? TEMPLATE_NAME : "hello_world"), data });
  } catch (e) { res.status(502).json({ ok: false, error: e.message, details: e.details }); }
});

// end-of-day summary
app.post("/api/send-summary", async (req, res) => {
  if (!configured()) return res.status(400).json({ ok: false, error: "Server not configured." });
  const b = req.body || {};
  const to = b.to || RECIPIENT_MSISDN;
  try {
    let payload;
    if (SUMMARY_TEMPLATE_NAME) {
      // Expected body variables: {{1}} opening {{2}} inflow {{3}} outflow {{4}} net {{5}} closing {{6}} count {{7}} volume
      const params = [naira(b.opening), naira(b.inflow), naira(b.outflow), naira(b.net), naira(b.closing), b.count, naira(b.volume)].map(p);
      payload = {
        messaging_product: "whatsapp", to, type: "template",
        template: { name: SUMMARY_TEMPLATE_NAME, language: { code: TEMPLATE_LANG }, components: [{ type: "body", parameters: params }] },
      };
    } else {
      payload = helloWorld(to);
    }
    const data = await sendToWhatsApp(payload);
    res.json({ ok: true, id: data?.messages?.[0]?.id });
  } catch (e) { res.status(502).json({ ok: false, error: e.message, details: e.details }); }
});

app.listen(PORT, () => {
  console.log(`\n  Octave Chime — WhatsApp alerts`);
  console.log(`  ▸ Front-end:  http://localhost:${PORT}`);
  console.log(`  ▸ Recipient:  ${RECIPIENT_MSISDN}`);
  console.log(`  ▸ WhatsApp credentials ${configured() ? "loaded" : "MISSING - set them in .env"}\n`);
});
