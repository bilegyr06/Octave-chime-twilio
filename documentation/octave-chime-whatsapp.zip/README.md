# Octave Chime — WhatsApp Transaction Alerts

Access Bank concept demo: a simulation banking app whose transactions fire **real
WhatsApp messages** to **0803 200 2338** (`2348032002338`) through the WhatsApp
Cloud API. Built by Octave Analytics.

The token lives on the server, never in the browser — which is the whole reason
this needs a backend rather than a plain web page.

---

## What you need
- **Node.js 18+** (uses built-in `fetch`)
- A **Meta WhatsApp Business Platform** app (free to create)

## 1. Get WhatsApp Cloud API credentials
1. Go to **developers.facebook.com** → create an app → add the **WhatsApp** product.
2. Open **WhatsApp → API Setup**. Copy:
   - the **Temporary access token** (valid 24h — fine for testing), and
   - the **Phone number ID** (the *test sender* Meta gives you).
3. Under **To**, add **2348032002338** as a recipient and verify it with the code
   WhatsApp sends. In test mode you can add up to 5 verified recipients.

> The temporary token expires daily. For something that keeps running, create a
> **System User** in Business Settings and generate a **permanent token** with the
> `whatsapp_business_messaging` permission.

## 2. Configure
```bash
cp .env.example .env
# open .env and paste your WHATSAPP_TOKEN and WHATSAPP_PHONE_NUMBER_ID
```

## 3. Run
```bash
npm install
npm start
```
Open **http://localhost:3000**, click **Launch the demo platform**, then in
**Delivery settings** switch to **Live WhatsApp** and press **Send test message**.
A `hello_world` message should land on 0803 200 2338. Now run a transaction
(Send money / Pay a bill) and the alert is delivered for real.

---

## From test to real transaction alerts
`hello_world` proves delivery but has no dynamic content. For real alerts:

1. In **WhatsApp Manager → Message templates**, create a **UTILITY** template,
   language English, with **6 body variables**, e.g.:

   > {{1}} Alert on your Access Bank account. Amount: {{2}}. {{3}} — {{4}}.
   > Available balance: {{5}}. Ref: {{6}}. Not you? Reply REPORT.

2. Once approved, set its name in `.env`:
   ```
   TEMPLATE_NAME=txn_alert
   ```
   The server fills the variables in this order:
   `kind, amount, channel, party, balance, ref`.
3. (Optional) create a 7-variable summary template and set `SUMMARY_TEMPLATE_NAME`
   (`opening, inflow, outflow, net, closing, count, volume`).

## Deploy it (so the demo works from a public URL)
Push to **Render**, **Railway**, or **Fly.io** and set the same `.env` values as
environment variables in the dashboard. The front-end is served by the same app,
so it just works. If you host the front-end separately, paste the backend's URL
into the **Backend URL** field in Delivery settings.

## Endpoints
| Method | Path | Purpose |
|---|---|---|
| GET  | `/api/health` | config + connectivity check |
| POST | `/api/send-test` | send `hello_world` |
| POST | `/api/send-alert` | send a transaction alert |
| POST | `/api/send-summary` | send the end-of-day summary |

## Notes
- **Cost:** Meta bills utility messages per delivery (~₦14 to Nigerian numbers at
  recent rates); test messages to your verified recipients use Meta's free tier.
- **Business-initiated messages** require an approved template. Free-form text only
  works inside the 24-hour window after the user messages you first.
- Going to production (beyond 5 test recipients) needs **business verification**.
- This is a simulation — no real accounts or money movement.
